describe("Collision detection", function() {
    it("should return true if points collide", function() {
        expect(detectCollision(0, 0, 0, 0)).toEqual(true);
        expect(detectCollision(100, 100, 100, 100)).toEqual(true);
        expect(detectCollision(99, 100, 100, 100)).toEqual(false);
        expect(detectCollision(100, 99, 100, 100)).toEqual(false);
        expect(detectCollision(100, 100, 99, 100)).toEqual(false);
        expect(detectCollision(100, 100, 100, 99)).toEqual(false);
    });
});

describe("creates 'virtual frame' encompassing canvas", function() {
    it("should return an array", function() {
        expect(createVirtualFrame(2, 2)).toEqual(jasmine.any(Array));
    });

    it("should return an array representing the virtual frame", function() {
        expect(createVirtualFrame(2, 2, 1)).toEqual([[-1, -1], [-1, 0], [-1, 1], [-1, 2], 
                                                  [0, -1], [0, 2], [1, -1], [1, 2],
                                                  [2, -1], [2, 0], [2, 1], [2, 2]]
                                                );
        expect(createVirtualFrame(3, 3, 1)).toEqual([[-1, -1,], [-1, 0], [-1, 1], [-1, 2], 
                                                  [-1, 3], [0, -1], [0, 3], [1, -1],
                                                  [1, 3], [2, -1], [2, 3], [3, -1],
                                                   [3, 0], [3, 1], [3, 2], [3, 3]]);
    });
});

describe("checks if there will be a collision", function() {
    it("should return a boolean value", function () {
        expect(willItCollide([1,2], [[0,0], [0,1]])).toEqual(jasmine.any(Boolean));
    });

    it("should return true when point collides", function () {
        expect(willItCollide([1, 2], [[0, 0], [0, 1], [1,2]])).toEqual(true);
    });

    it("should return false when point does not collide", function () {
        expect(willItCollide([1, 2], [[0, 0], [0, 1]])).toEqual(false);
    });
});

//TODO -test wether either side of the canvas is envenly divisible by square side