describe("test number format has commas (,) for decimal separator", function() {
    it("should return a number without dots"), function() {
        expect(parseChar(25.4)).toEqual(25,4);
    }
});