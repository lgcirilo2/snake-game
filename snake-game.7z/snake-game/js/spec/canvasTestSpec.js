describe("Collision detection", function() {
    it("should return true if points collide", function() {
        expect(detectCollision(0, 0, 0, 0)).toEqual(true);
        expect(detectCollision(100, 100, 100, 100)).toEqual(true);
        expect(detectCollision(99, 100, 100, 100)).toEqual(false);
        expect(detectCollision(100, 99, 100, 100)).toEqual(false);
        expect(detectCollision(100, 100, 99, 100)).toEqual(false);
        expect(detectCollision(100, 100, 100, 99)).toEqual(false);
    });
});

describe("creates 'virtual frame' encompassing canvas", function() {
    it("should return an array of points representing top left hand corners of squares\
        of frame", function() {
            expect(createVirtualFrame(2, 2)).toEqual([[-1, -1], [0, -1], [1, -1], [2, -1], 
                                                      [-1, 0], [0, 0], [1, 0], [2, 0],
                                                      [-1, 1], [0, 1], [1, 1], [2, 1], 
                                                      [-1, 2], [0, 2], [1, 2], [2, 2]]
                                                    );
    });
});