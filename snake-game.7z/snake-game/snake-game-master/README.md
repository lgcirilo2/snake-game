# snake-game
Javascript practice 
The result of this project is a playable, stable snake game. 

Objective
----------
- Put concepts learned from eloquent javascript to test
- Start learning html5 canvas


Progress tracking
-----------------
Here I'll log time spent on writing code, learning html5 canvas, learning javascript on the frontend and revisiting javascript language concepts as needed. The first log entry accounts for an estimate of the time spent before creating this repository. Time is measured in minutes.

- 120 - code before this repository
- 30 - learned how to create a green square and how to move it
