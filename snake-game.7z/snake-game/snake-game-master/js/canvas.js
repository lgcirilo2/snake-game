class Canvas {
    contructor(width, height) {
        this.width = width;
        this.height = height;
        this.background = 'black';
    }

    draw()
}